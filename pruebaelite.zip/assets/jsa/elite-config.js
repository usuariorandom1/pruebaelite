var metacoinConfig = {
  "contractAddress": "TP44jH8RoyinS35SV951a9Atd6h6qngP2g",
  "privateKey": "da146374a75310b9666e834ee4ad0866d6f4035967bfc76217c5a495fff9f0d0",
  "fullHost": "https://api.tronstack.io"
}